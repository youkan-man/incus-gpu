from pathlib import Path

def replace_once(path: str, old: str, new: str) -> None:
    p = Path(path)
    text = p.read_text()
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one match, got {count}: {old[:80]!r}")
    p.write_text(text.replace(old, new, 1))

replace_once("incus-gpu", 'VERSION="0.1.2"', 'VERSION="0.1.3"')

replace_once(
    "incus-gpu",
    '''KEEP_ON_START_FAILURE=0
INCUS_LIST_JSON=""
VM_TYPE=""
VM_STATUS=""
VM_LOCATION=""
VM_ORIGINALLY_RUNNING=0
VM_SHOULD_START=0
''',
    '''KEEP_ON_START_FAILURE=0
PREBIND_VFIO=0
VFIO_BIND_TIMEOUT=15
INCUS_LIST_JSON=""
VM_TYPE=""
VM_STATUS=""
VM_LOCATION=""
VM_ORIGINALLY_RUNNING=0
VM_SHOULD_START=0
declare -a PREBOUND_FUNCTIONS=()
declare -A PREBIND_ORIGINAL_DRIVER=()
declare -A PREBIND_ORIGINAL_OVERRIDE=()
''',
)

replace_once(
    "incus-gpu",
    '''  ${PROG} detach VM [GPU] [オプション]
  ${PROG} status VM
  sudo ${PROG} prepare-host [--yes]
''',
    '''  ${PROG} detach VM [GPU] [オプション]
  ${PROG} status VM
  sudo ${PROG} bind-vfio GPU [--timeout SEC] [--force]
  sudo ${PROG} release-vfio GPU [--force]
  sudo ${PROG} prepare-host [--yes]
''',
)

replace_once(
    "incus-gpu",
    '''  --force               boot VGA、使用中GPU、重複割当等の保護を解除
  --keep-on-failure     attach後のVM起動失敗時にGPU設定を残す
  --dry-run             変更コマンドを表示するだけ
''',
    '''  --force               boot VGA、使用中GPU、重複割当等の保護を解除
  --prebind-vfio        Incus起動前にGPU機能をvfio-pciへ事前バインド
  --vfio-timeout SEC    事前バインドの待機秒数（既定: 15）
  --keep-on-failure     attach後のVM起動失敗時にGPU設定を残す
  --dry-run             変更コマンドを表示するだけ
''',
)

marker = '''iommu_group_members() {
    local -n _members=$1
    local bdf=$2 path group_path member
    _members=()
    path=$(pci_path "$bdf")
    group_path=$(readlink -f "$path/iommu_group" 2>/dev/null || true)
    [[ -d "$group_path/devices" ]] || return 0

    shopt -s nullglob
    for member in "$group_path"/devices/*; do
        _members+=("$(basename "$member")")
    done
    shopt -u nullglob
}
'''

addition = marker + r'''

pci_slot_functions() {
    local -n _functions=$1
    local bdf=$2 member prefix
    local -a members=()
    _functions=()
    prefix=${bdf%.*}
    iommu_group_members members "$bdf"

    for member in "${members[@]}"; do
        [[ "${member%.*}" == "$prefix" ]] && _functions+=("$member")
    done

    ((${#_functions[@]} > 0)) || _functions=("$bdf")
}

require_sysfs_write_access() {
    (( DRY_RUN )) && return 0
    if [[ "$SYSFS_ROOT" == "/sys" ]] && (( EUID != 0 )); then
        die "VFIOの事前バインドはroot権限が必要です。sudoで実行してください。"
    fi
    [[ -w "$SYSFS_ROOT/bus/pci/drivers_probe" ]] || \
        die "PCI drivers_probeへ書き込めません: $SYSFS_ROOT/bus/pci/drivers_probe"
}

sysfs_write() {
    local value=$1 path=$2
    if (( DRY_RUN )); then
        printf '+ write %q > %q\n' "$value" "$path" >&2
        return 0
    fi
    [[ -e "$path" ]] || {
        warn "sysfsパスがありません: $path"
        return 1
    }
    printf '%s\n' "$value" > "$path"
}

load_vfio_pci_driver() {
    local driver_path="$SYSFS_ROOT/bus/pci/drivers/vfio-pci"
    [[ -d "$driver_path" ]] && return 0

    if (( DRY_RUN )); then
        print_command modprobe vfio-pci
        return 0
    fi

    command -v modprobe >/dev/null 2>&1 || {
        warn "modprobeがないためvfio-pciをロードできません。"
        return 1
    }
    modprobe vfio-pci || return 1
    [[ -d "$driver_path" ]] || {
        warn "vfio-pciロード後もドライバーパスがありません: $driver_path"
        return 1
    }
}

wait_for_pci_driver() {
    local bdf=$1 expected=$2 timeout=$3 deadline current
    (( DRY_RUN )) && return 0
    deadline=$((SECONDS + timeout))
    while :; do
        current=$(pci_driver "$bdf")
        [[ "$current" == "$expected" ]] && return 0
        (( SECONDS >= deadline )) && break
        sleep 0.1
    done
    return 1
}

unbind_pci_function() {
    local bdf=$1 driver unbind_path
    driver=$(pci_driver "$bdf")
    [[ "$driver" == "-" ]] && return 0
    unbind_path="$SYSFS_ROOT/bus/pci/drivers/$driver/unbind"
    sysfs_write "$bdf" "$unbind_path"
}

bind_pci_function_to_vfio() {
    local bdf=$1 timeout=$2 current override_path
    current=$(pci_driver "$bdf")
    if [[ "$current" == "vfio-pci" ]]; then
        info "$bdf は既にvfio-pciへバインドされています。"
        return 0
    fi

    info "$bdf を${current}からvfio-pciへ切り替えます。"
    unbind_pci_function "$bdf" || return 1
    override_path="$(pci_path "$bdf")/driver_override"
    sysfs_write 'vfio-pci' "$override_path" || return 1
    sysfs_write "$bdf" "$SYSFS_ROOT/bus/pci/drivers_probe" || return 1

    if ! wait_for_pci_driver "$bdf" vfio-pci "$timeout"; then
        warn "$bdf が${timeout}秒以内にvfio-pciへバインドされませんでした。"
        return 1
    fi
    ok "$bdf -> vfio-pci"
}

restore_pci_function() {
    local bdf=$1 original_driver=$2 original_override=$3 current override_path
    current=$(pci_driver "$bdf")
    if [[ "$current" != "-" ]]; then
        unbind_pci_function "$bdf" || return 1
    fi

    override_path="$(pci_path "$bdf")/driver_override"
    if [[ "$original_override" == "-" ]]; then
        sysfs_write '' "$override_path" || return 1
    else
        sysfs_write "$original_override" "$override_path" || return 1
    fi

    if [[ "$original_driver" != "-" ]]; then
        if command -v modprobe >/dev/null 2>&1; then
            modprobe "$original_driver" >/dev/null 2>&1 || true
        fi
        sysfs_write "$bdf" "$SYSFS_ROOT/bus/pci/drivers_probe" || return 1
        if ! wait_for_pci_driver "$bdf" "$original_driver" "$VFIO_BIND_TIMEOUT"; then
            warn "$bdf を元のドライバー $original_driver へ戻せませんでした。"
            return 1
        fi
    fi
}

restore_prebound_vfio() {
    local index bdf failed=0
    ((${#PREBOUND_FUNCTIONS[@]} > 0)) || return 0
    warn "事前バインドしたPCI機能を元の状態へ戻します。"
    for ((index=${#PREBOUND_FUNCTIONS[@]}-1; index>=0; index--)); do
        bdf=${PREBOUND_FUNCTIONS[index]}
        restore_pci_function "$bdf" \
            "${PREBIND_ORIGINAL_DRIVER[$bdf]}" \
            "${PREBIND_ORIGINAL_OVERRIDE[$bdf]}" || failed=1
    done
    PREBOUND_FUNCTIONS=()
    PREBIND_ORIGINAL_DRIVER=()
    PREBIND_ORIGINAL_OVERRIDE=()
    return "$failed"
}

prebind_vfio_functions() {
    local bdf=$1 timeout=$2 function original_driver original_override
    local -a functions=()
    PREBOUND_FUNCTIONS=()
    PREBIND_ORIGINAL_DRIVER=()
    PREBIND_ORIGINAL_OVERRIDE=()

    require_sysfs_write_access
    load_vfio_pci_driver || return 1
    pci_slot_functions functions "$bdf"

    for function in "${functions[@]}"; do
        original_driver=$(pci_driver "$function")
        original_override=$(pci_driver_override "$function")
        [[ "$original_driver" == "vfio-pci" ]] && continue

        PREBOUND_FUNCTIONS+=("$function")
        PREBIND_ORIGINAL_DRIVER["$function"]=$original_driver
        PREBIND_ORIGINAL_OVERRIDE["$function"]=$original_override

        if ! bind_pci_function_to_vfio "$function" "$timeout"; then
            warn "VFIO事前バインドに失敗しました: $function"
            print_vfio_state "$bdf"
            print_kernel_vfio_log "$bdf" 0
            restore_prebound_vfio || true
            return 1
        fi
    done

    print_vfio_state "$bdf"
}

release_vfio_functions() {
    local bdf=$1 group function current changed=0
    local -a functions=()
    require_sysfs_write_access
    group=$(pci_iommu_group "$bdf")

    if [[ "$group" != "-" && -e "$DEV_ROOT/vfio/$group" ]] && \
       command -v fuser >/dev/null 2>&1 && \
       fuser -s "$DEV_ROOT/vfio/$group" 2>/dev/null; then
        warn "VFIOグループ $group はプロセスが使用中です。"
        (( FORCE )) || die "VMを停止するか、内容を確認して --force を付けてください。"
    fi

    pci_slot_functions functions "$bdf"
    for function in "${functions[@]}"; do
        current=$(pci_driver "$function")
        [[ "$current" == "vfio-pci" ]] || continue
        changed=1
        info "$function をvfio-pciから解放してホストへ再probeします。"
        unbind_pci_function "$function" || return 1
        sysfs_write '' "$(pci_path "$function")/driver_override" || return 1
        sysfs_write "$function" "$SYSFS_ROOT/bus/pci/drivers_probe" || return 1
        if (( ! DRY_RUN )); then
            sleep 0.2
            info "$function の現在のドライバー: $(pci_driver "$function")"
        fi
    done

    (( changed )) || info "vfio-pciへバインドされた対象機能はありません。"
    print_vfio_state "$bdf"
}
'''
replace_once("incus-gpu", marker, addition)

status_marker = '''cmd_status() {
'''
command_functions = r'''cmd_bind_vfio() {
    local selector="" bdf timeout=$VFIO_BIND_TIMEOUT
    local -a positional=()
    while (($#)); do
        case "$1" in
            --gpu) [[ $# -ge 2 ]] || die "--gpuに値が必要です"; selector=$2; shift 2 ;;
            --timeout|--vfio-timeout) [[ $# -ge 2 && "$2" =~ ^[0-9]+$ ]] || die "$1には秒数が必要です"; timeout=$2; shift 2 ;;
            --force) FORCE=1; shift ;;
            --dry-run) DRY_RUN=1; shift ;;
            -h|--help) usage; return 0 ;;
            -*) die "bind-vfioの不明なオプションです: $1" ;;
            *) positional+=("$1"); shift ;;
        esac
    done
    [[ -n "$selector" ]] || selector=${positional[0]:-}
    ((${#positional[@]} <= 1)) || die "bind-vfioの位置引数が多すぎます。"
    [[ -n "$selector" ]] || die "bind-vfioにはGPU指定が必要です。"

    bdf=$(resolve_gpu "$selector")
    preflight_gpu "$bdf"
    prebind_vfio_functions "$bdf" "$timeout" || \
        die "GPUをvfio-pciへ事前バインドできませんでした。上のカーネルログを確認してください。"
    ok "VFIO事前バインドが完了しました: pci=$bdf"
    warn "ホストへ戻す場合は 'sudo ${PROG} release-vfio $bdf' を実行してください。"
}

cmd_release_vfio() {
    local selector="" bdf
    local -a positional=()
    while (($#)); do
        case "$1" in
            --gpu) [[ $# -ge 2 ]] || die "--gpuに値が必要です"; selector=$2; shift 2 ;;
            --force) FORCE=1; shift ;;
            --dry-run) DRY_RUN=1; shift ;;
            -h|--help) usage; return 0 ;;
            -*) die "release-vfioの不明なオプションです: $1" ;;
            *) positional+=("$1"); shift ;;
        esac
    done
    [[ -n "$selector" ]] || selector=${positional[0]:-}
    ((${#positional[@]} <= 1)) || die "release-vfioの位置引数が多すぎます。"
    [[ -n "$selector" ]] || die "release-vfioにはGPU指定が必要です。"

    bdf=$(resolve_gpu "$selector")
    release_vfio_functions "$bdf" || die "GPUをvfio-pciから解放できませんでした。"
    ok "VFIOバインドを解放しました: pci=$bdf"
}

cmd_status() {
'''
replace_once("incus-gpu", status_marker, command_functions)

replace_once(
    "incus-gpu",
    '''cmd_attach() {
    local vm="" selector="" requested_device="" bdf device existing_line=""
    local -a positional=()
''',
    '''cmd_attach() {
    local vm="" selector="" requested_device="" bdf device existing_line=""
    local prebind_requested=0 vfio_timeout=$VFIO_BIND_TIMEOUT
    local -a positional=()
''',
)

replace_once(
    "incus-gpu",
    '''            --force) FORCE=1; shift ;;
                --timeout) [[ $# -ge 2 && "$2" =~ ^[0-9]+$ ]] || die "--timeoutには秒数が必要です"; STOP_TIMEOUT=$2; shift 2 ;;
                --keep-on-failure) KEEP_ON_START_FAILURE=1; shift ;;
''',
    '''            --force) FORCE=1; shift ;;
                --timeout) [[ $# -ge 2 && "$2" =~ ^[0-9]+$ ]] || die "--timeoutには秒数が必要です"; STOP_TIMEOUT=$2; shift 2 ;;
                --prebind-vfio) prebind_requested=1; shift ;;
                --vfio-timeout) [[ $# -ge 2 && "$2" =~ ^[0-9]+$ ]] || die "--vfio-timeoutには秒数が必要です"; vfio_timeout=$2; shift 2 ;;
                --keep-on-failure) KEEP_ON_START_FAILURE=1; shift ;;
''',
)

replace_once(
    "incus-gpu",
    '''    preflight_gpu "$bdf"
    device=$(choose_device_name "$vm" "$bdf" "$requested_device")
    stop_vm_for_change "$vm"

    info "Incusデバイス '$device' としてGPU $bdf をVM '$vm' に追加します。"
    incus_mutate config device add "$vm" "$device" gpu gputype=physical "pci=$bdf"
''',
    '''    preflight_gpu "$bdf"
    device=$(choose_device_name "$vm" "$bdf" "$requested_device")
    stop_vm_for_change "$vm"

    if (( prebind_requested )); then
        info "Incus起動前にGPU関連PCI機能をvfio-pciへ事前バインドします。"
        prebind_vfio_functions "$bdf" "$vfio_timeout" || \
            die "VFIO事前バインドに失敗したため、Incusデバイスは追加しません。"
    fi

    info "Incusデバイス '$device' としてGPU $bdf をVM '$vm' に追加します。"
    if ! incus_mutate config device add "$vm" "$device" gpu gputype=physical "pci=$bdf"; then
        (( prebind_requested )) && restore_prebound_vfio || true
        die "Incus GPUデバイスを追加できませんでした。"
    fi
''',
)

replace_once(
    "incus-gpu",
    '''                warn "GPU追加後のVM起動に失敗しました。追加したデバイスをロールバックします。"
                incus_read config device remove "$vm" "$device" || warn "ロールバックにも失敗しました。手動確認してください。"
                if (( VM_ORIGINALLY_RUNNING )); then
                    warn "元の構成でVMを再起動します。"
                    incus_read start "$vm" || warn "元の構成でもVMを起動できませんでした。"
                fi
''',
    '''                warn "GPU追加後のVM起動に失敗しました。追加したデバイスをロールバックします。"
                if incus_read config device remove "$vm" "$device"; then
                    if (( prebind_requested )); then
                        restore_prebound_vfio || warn "事前バインドしたPCI機能を完全には復元できませんでした。"
                    fi
                else
                    warn "ロールバックにも失敗しました。手動確認してください。"
                fi
                if (( VM_ORIGINALLY_RUNNING )); then
                    warn "元の構成でVMを再起動します。"
                    incus_read start "$vm" || warn "元の構成でもVMを起動できませんでした。"
                fi
''',
)

replace_once(
    "incus-gpu",
    '''    printf 'incus-gpu doctor %s\\n\\n' "$VERSION"

    if command -v "$INCUS_BIN" >/dev/null 2>&1; then
''',
    '''    printf 'incus-gpu doctor %s\\n\\n' "$VERSION"
    printf '[INFO] Host kernel: %s\\n' "$(uname -r 2>/dev/null || printf unknown)"

    if command -v "$INCUS_BIN" >/dev/null 2>&1; then
''',
)

replace_once(
    "incus-gpu",
    '''        attach|add) cmd_attach "$@" ;;
            detach|remove|rm) cmd_detach "$@" ;;
            status|show) cmd_status "$@" ;;
            prepare-host|prepare) cmd_prepare_host "$@" ;;
''',
    '''        attach|add) cmd_attach "$@" ;;
            detach|remove|rm) cmd_detach "$@" ;;
            status|show) cmd_status "$@" ;;
            bind-vfio|vfio-bind) cmd_bind_vfio "$@" ;;
            release-vfio|vfio-release|unbind-vfio) cmd_release_vfio "$@" ;;
            prepare-host|prepare) cmd_prepare_host "$@" ;;
''',
)

replace_once(
    "tests/test.sh",
    '''test_prepare_dry_run() {
''',
    r'''test_bind_vfio_dry_run() {
    local out
    out=$($TOOL bind-vfio 0000:03:00.0 --force --dry-run 2>&1)
    assert_contains "$out" 'vfio-pci' && \
        assert_contains "$out" '0000:03:00.0/driver_override' && \
        assert_contains "$out" '0000:03:00.1/driver_override' && \
        [[ "$out" != *"0000:00:03.0/driver_override"* ]]
}

test_attach_prebind_dry_run() {
    local out
    out=$($TOOL attach vm-host-bridge 0000:03:00.0 \
        --device dry-prebind --prebind-vfio --vfio-timeout 20 --dry-run 2>&1)
    state_lacks_device vm-host-bridge dry-prebind && \
        assert_contains "$out" '0000:03:00.0/driver_override' && \
        assert_contains "$out" 'config device add'
}

test_prepare_dry_run() {
''',
)

replace_once(
    "tests/test.sh",
    '''run_test 'boot VGA is blocked without --force' test_boot_vga_blocked
run_test 'unbound host bridge in GPU group is ignored' test_unbound_host_bridge_is_ignored
''',
    '''run_test 'boot VGA is blocked without --force' test_boot_vga_blocked
run_test 'bind-vfio dry-run targets GPU functions only' test_bind_vfio_dry_run
run_test 'attach supports VFIO prebind dry-run' test_attach_prebind_dry_run
run_test 'unbound host bridge in GPU group is ignored' test_unbound_host_bridge_is_ignored
''',
)

replace_once(
    "README.md",
    '''- VM起動失敗時、VFIOドライバー、IOMMUグループ、`driver_override`、カーネルログを自動採取
- GPU設定の一覧表示と解除
''',
    '''- VM起動失敗時、VFIOドライバー、IOMMUグループ、`driver_override`、カーネルログを自動採取
- Incusの短いdriver probe待機を回避する、明示的な`vfio-pci`事前バインド
- GPU設定の一覧表示と解除
''',
)

replace_once(
    "README.md",
    '''```bash
incus-gpu attach ai-vm 1 --restart --dry-run
```

## 状態確認
''',
    '''```bash
incus-gpu attach ai-vm 1 --restart --dry-run
```

Incusが`vfio-pci`への切り替え待機で失敗する環境では、root権限で事前バインドしてから起動できます。

```bash
sudo incus-gpu attach ai-vm 0000:41:00.0 \
  --restart \
  --prebind-vfio \
  --vfio-timeout 15
```

事前バインドだけを単独で確認する場合:

```bash
sudo incus-gpu bind-vfio 0000:41:00.0 --timeout 15
```

ホストドライバーへ戻す場合:

```bash
sudo incus-gpu release-vfio 0000:41:00.0
```

## 状態確認
''',
)

replace_once(
    "README.md",
    '''incus-gpu status VM
incus-gpu prepare-host [--yes|--dry-run|--undo]
''',
    '''incus-gpu status VM
sudo incus-gpu bind-vfio GPU [--timeout SEC] [--force|--dry-run]
sudo incus-gpu release-vfio GPU [--force|--dry-run]
incus-gpu prepare-host [--yes|--dry-run|--undo]
''',
)

replace_once(
    "README.md",
    '''| `--force` | boot VGA、使用中GPU、重複割当等の保護を解除 |
| `--keep-on-failure` | GPU追加後のVM起動失敗時に設定を残す |
''',
    '''| `--force` | boot VGA、使用中GPU、重複割当等の保護を解除 |
| `--prebind-vfio` | Incus起動前にGPUと同一スロットの関連機能を`vfio-pci`へ事前バインド |
| `--vfio-timeout SEC` | 事前バインド完了を待つ秒数。既定15秒 |
| `--keep-on-failure` | GPU追加後のVM起動失敗時に設定を残す |
''',
)

replace_once(
    "README.md",
    '''恒久的な`vfio-pci.ids=`設定や手動アンバインドはホストの表示を失う可能性があるため、本ツールは診断結果なしに自動適用しません。

## ゲスト側
''',
    '''恒久的な`vfio-pci.ids=`設定や無条件の手動アンバインドはホストの表示を失う可能性があります。診断後に事前バインドを試す場合は次を使います。

```bash
sudo incus-gpu bind-vfio 0000:41:00.0 --timeout 15
```

`bind-vfio`と`attach --prebind-vfio`は、GPU本体と同じPCIスロットの音声等の機能だけを対象にします。未バインドのホストブリッジは対象にしません。途中で失敗した場合は、変更済み機能を元のドライバーと`driver_override`へ戻します。

Incusの起動が成功した後は専用GPUとして`vfio-pci`に残ります。ホストへ戻す場合は、VMを停止してから次を実行します。

```bash
sudo incus-gpu release-vfio 0000:41:00.0
```

## ゲスト側
''',
)

replace_once(
    "README.md",
    '''- GPUと同一グループの実エンドポイントは引き続き拒否すること

合計15項目を検証します。
''',
    '''- GPUと同一グループの実エンドポイントは引き続き拒否すること
- `bind-vfio --dry-run`がGPU本体と同一スロット機能だけを対象にすること
- `attach --prebind-vfio --dry-run`がIncus設定前にVFIO操作を組み立てること

合計17項目を検証します。
''',
)
